const Destination = () => {
    return (
        <></>
    )
}

export default Destination;