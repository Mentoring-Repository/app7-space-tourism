const Technology = () => {
    return (
        <></>
    )
}

export default Technology;