import './Destination.css';

const Destination = () => {
    return (
        <></>
    )
}

export default Destination;