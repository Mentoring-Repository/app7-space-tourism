import './TechnologyList.css';

const TechnologyList = () => {
    return (
        <></>
    )
}

export default TechnologyList;