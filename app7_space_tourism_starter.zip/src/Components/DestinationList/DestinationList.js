import './DestinationList.css';

const DestinationList = () => {
    return (
        <></>
    )
}

export default DestinationList;