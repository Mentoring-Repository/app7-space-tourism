import './Technology.css';

const Technology = () => {
    return (
        <></>
    )
}

export default Technology;